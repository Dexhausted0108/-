﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SchoolPortalLib
{
    public class SchoolPortalLib
    {
        private const char Y = ' ';
        public string GetStudentNumber(Student student)
        {
            string[] initials = student.fio.Split(' ');
            string numStudentTicket = $"{student.year.ToString()}." +
                $"{student.group.ToString()}." +
                $"{initials[0][0]}{initials[1][0]}{initials[2][0]}";
            return numStudentTicket;
        }
        public double MinAverage(string[] marks)
        {
            int sum = 0;
            foreach (string a in marks)
            {
                sum += int.Parse(a);
            }
            return sum / marks.Length;
        }
        public int[] GetCountTruancy(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var b = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var c in b)
            {
                int prom = marks.FindAll(m => m.date.Month == c.date && m.estimation == "б").Count;
                res.Add(c.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
        public int[] GetCountDisease(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var b = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var c in b)
            {
                int prom = marks.FindAll(m => m.date.Month == c.date && m.estimation == "н").Count;
                res.Add(c.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
        private static int[] GetCountPassed(List<Mark> marks, string passed)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var b = (from m in marks
                     group m by m.date.Month into g
                     select new { date = g.Key }).ToList();
            foreach (var t in b)
            {
                int c = marks.FindAll(m => m.date.Month == t.date && m.estimation == passed).Count;
                res.Add(t.date, c);
            }
            return res.Select(x => x.Value).ToArray();
        }
        public List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            Random rand = new Random();
            string[] marks = { "2", "3", "4", "5", "н", "б", "п", "" };
            double day;
            List<Mark> StudentMarkList = new List<Mark>();
            foreach (Student student in students)
            {
                day = 0;
                for (int i = 0; i < 10; i++)
                {
                    Mark mark = new Mark()
                    {
                        date = now.AddDays(day),
                        estimation = marks[rand.Next(8)]
                    };
                    day++;
                    StudentMarkList.Add(mark);
                }
            }
            return StudentMarkList;
        }
    }
    public class Student
    {
        public int year { get; set; }
        public int group { get; set; }
        public string fio { get; set; }
        public Student(int y, int g, string f)
        {
            year = y;
            group = g;
            fio = f;
        }
    }
    public class Mark
    {
        public DateTime date { get; set; }
        public string estimation { get; set; }
        public Student student { get; set; }
    }
}
