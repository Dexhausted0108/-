﻿using System;
using System.Collections.Generic;
using SchoolPortalLib;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolPortal
{
    public class ClassPortal
    {
        public static SchoolPortalLib.SchoolPortalLib cls = new SchoolPortalLib.SchoolPortalLib();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();

            List<Student> student = new List<Student>
            {
                new Student(2002,820,"Евгений Александр Семенович"),
                new Student(2001,818,"Кузнецов Семен Паронов"),
                new Student(2002,818,"Зиранин Михаил Елестратович"),
                new Student(2003,819,"Петроградова Марина Александровна"),
                new Student(2002,821,"Комаров Елисей Вадимович"),
                new Student(2001,820,"Суратов Илья Сергеевич"),
                new Student(2002,819,"Огапов Валерий Никитич"),
                new Student(2002,821,"Мосалов Ибрагим Максимович"),
                new Student(2002,821,"Костин Данила Михайлович"),
                new Student(2001,818,"Виртунов Петр Елесеевич"),
                new Student(2003,822,"Кылагин Олег Растиславович")
            };

            //Заполнение оценками
            marks.AddRange(cls.GetMarks(DateTime.Parse("04.01.2022"), student));
            marks.AddRange(cls.GetMarks(DateTime.Parse("06.03.2022"), student));
            marks.AddRange(cls.GetMarks(DateTime.Parse("21.02.2022"), student));
            marks.AddRange(cls.GetMarks(DateTime.Parse("18.08.2022"), student));
            marks.AddRange(cls.GetMarks(DateTime.Parse("28.11.2022"), student));

            //Вывод всех оценок
            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.estimation} - {m.student.fio}");
            }
            Console.WriteLine();

            //Вывод прогулов за месяцы
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Вывод болезней за месяц
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Студенческие билеты студентов
            foreach (Student std in student)
            {
                Console.WriteLine(cls.GetStudentNumber(std));
            }
            Console.WriteLine();

            //Среднее арифметическое оценок в меньшую сторону
            Console.WriteLine(cls.MinAverage(new string[6] { "3", "2", "3", "4", "4", "5" }));
            Console.ReadKey();

        }
    }
}